<link rel="stylesheet" href="<?php echo constant("SITE_URL"); ?>/assets/bootstrap/bootstrap-icons.css">
<link rel="icon" type="image/x-icon" href="<?php echo constant("SITE_URL"); ?>/uploads/svg.svg">
<link rel="stylesheet" href="<?php echo constant("SITE_URL"); ?>/assets/css/custom.css">
<link rel="stylesheet" href="<?php echo constant("SITE_URL"); ?>/assets/bootstrap/bootstrap.rtl.min.css" integrity="sha384-gXt9imSW0VcJVHezoNQsP+TNrjYXoGcrqBZJpry9zJt8PCQjobwmhMGaDHTASo9N" crossorigin="anonymous">