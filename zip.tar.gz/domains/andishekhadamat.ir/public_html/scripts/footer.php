<script src="<?php echo constant("SITE_URL"); ?>/assets/js/custom.js"></script>
<script src="<?php echo constant("SITE_URL"); ?>/assets/bootstrap/bootstrap.bundle.min.js"></script>
<script src="<?php echo constant("SITE_URL"); ?>/assets/bootstrap/sweetalert2@11.js"></script>
